public class WrapperArraySum
{
  public static void main(String x[])
  {
  Integer a[]={10,20,30,40};
  Integer sum=0,i;
   for(i=0 ; i<a.length ; i++)
  {
    sum=sum+a[i];
  }
  System.out.println("Sum of Array is"+sum);
  }
 }
	
    