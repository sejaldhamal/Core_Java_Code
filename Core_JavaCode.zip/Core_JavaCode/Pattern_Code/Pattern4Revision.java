public class Pattern1Revision
{
  public static void main(String x[])
  {
     int i,j;
	 boolean flag=true;

     for(i=1;i<=6;i++)
	 {   
		 for(j=1;j<=11;j++)