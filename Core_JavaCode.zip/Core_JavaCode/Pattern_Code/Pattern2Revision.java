public class Pattern2Revision
{
  public static void main(String x[])
  {
     int i,j;

     for(i=1;i<=6;i++)
	 {   
		 for(j=1;j<=6;j++)
		 {
		 if(j<=i)
		 {
		  System.out.printf("%d",j);
		    }
		  
		  }
		 System.out.println();
	
		   }
		}
      }
	  
	  /*
            1
            12
            123
            1234
            12345
            123456

*/