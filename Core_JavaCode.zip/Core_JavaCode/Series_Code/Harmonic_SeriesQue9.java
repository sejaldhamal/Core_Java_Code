/*Print the first N terms of a harmonic series (1, 1/2, 1/3, ...).*/

public class Harmonic_SeriesQue9
{
   public static void main(String x[])
   { 
   
   float i,h;   
   for( i=1 ; i<=10 ; i++)
       {
	          h=1/i;
	        System.out.println(h);
		    
	   }
	}
}
/*
Output:
C:\Program Files\Java\jdk1.8.0_202\bin>java Harmonic_SeriesQue9
1.0
0.5
0.33333334
0.25
0.2
0.16666667
0.14285715
0.125
0.11111111
0.1
*/