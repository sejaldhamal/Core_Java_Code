
/*Print the first 10 terms of the arithmetic series with a common difference of 3.*/


public class Series_Diff3
{
   public static void main(String x[])
   {    int k=3;
      
	   for(int i=1 ; i<=10 ; i++)
	  {
	     
		   int s=k*i;
			System.out.printf("%d ",s);
			
		}
	}
}