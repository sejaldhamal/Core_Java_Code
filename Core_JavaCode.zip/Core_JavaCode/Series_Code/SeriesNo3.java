public class SeriesNo3
{
public static void main(String x[])
{
int i,no=1;
while(no<=10)
{
i=no*no;
 System.out.printf(" %d",i);
no++;
}
}
}