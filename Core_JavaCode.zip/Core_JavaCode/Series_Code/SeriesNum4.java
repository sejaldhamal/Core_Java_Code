
public class SeriesNum4
{
public static void main(String x[])
{
int i,j=1,k=0;
for(i=1;i<=10;i++)

{
j=j+k;
System.out.printf(" %d",j);
k++;
}
}
}
