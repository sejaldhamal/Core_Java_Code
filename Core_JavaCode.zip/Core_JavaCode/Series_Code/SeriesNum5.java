public class SeriesNum5
{
public static void main(String x[])
{int i,j=0,k=0;
for(i=1;i<=18;i++)

{
if(i%2==1)
{
System.out.printf(" %d",j);
j=j+2;
}
else
{
System.out.printf(" %d",k);
k=k+1;
}
}
}
}
