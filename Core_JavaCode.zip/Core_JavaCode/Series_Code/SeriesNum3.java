public class SeriesNum3
{
public static void main(String x[])
{
int i,no=1;
if(no>=10)
{
i=no*no;
 System.out.println(i);
i++;
}
}
}