public class TestSeries
{
public static void main(String x[])
{
int i,j=1,k=1;
for(i=1;i<=16;i++)

{
if(i%2==1)
{
j=j+0;
System.out.printf(" %d",j);
j*2;
}
else
{
k=k+0;
System.out.printf(" %d",k);
k*2;

}
}
}
}