

/*Calculate the nth term of an arithmetic progression (AP).*/

public class Arithmetic_Progress_SeriesQue8
{
   public static void main(String x[])
   {    int a=2, n=5, d=3;
         int AP=a+(n-2)*d;
	        System.out.printf("%d ",AP);
		    }
          }
/*Output:
11
*/