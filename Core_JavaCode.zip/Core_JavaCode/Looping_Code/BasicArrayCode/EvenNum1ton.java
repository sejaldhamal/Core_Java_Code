
/*11. Even Numbers
Description: Write a program to print all even numbers between 1 and n.
Input: n = 10


Output: 2 4 6 8 10
*/



package BasicArrayCode;
public class EvenNum1ton {

	public static void main(String[] args) {
		for(int i=1 ; i<=100 ; i++)
		{
			if(i%2==0)
				
			{
				System.out.print(" "+i);
			}
		}

	}

}
