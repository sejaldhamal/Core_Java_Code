
/*16. Find Minimum Number
Description: Write a program to find the minimum number between two numbers.
Input: a = 10, b = 20


Output: 10


*/



package BasicArrayCode;

public class Q16MinimumNum {

	public static void main(String[] args) {
		int a=10;
		int b=20;
	if(a<b)
	{
		System.out.println(a);
	}
	else {
		System.out.println(b);
	}

	}

}
