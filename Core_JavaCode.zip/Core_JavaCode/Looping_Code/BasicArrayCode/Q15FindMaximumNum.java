
/*15. Find Maximum Number
Description: Write a program to find the maximum number between two numbers.
Input: a = 10, b = 20


Output: 20*/




package BasicArrayCode;
import java.util.*;
public class Q15FindMaximumNum {

	public static void main(String[] args) {
		int a=10;
		int b=20;
	if(a>b)
	{
		System.out.println(a);
	}
	else {
		System.out.println(b);
	}

	}

}
