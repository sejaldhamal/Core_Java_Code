
/*26. Multiplication of Two Numbers
Description: Write a program to multiply two numbers using loops.
Input: a = 3, b = 5
Output: 15
*/
package BasicArrayCode;
import java.util.*;
public class Q26MultiplicationOfTwoNum {

	public static void main(String[] args) {
		Scanner xyz=new Scanner(System.in);
		System.out.println("Enter two numbers");
		int a=xyz.nextInt();
		int b=xyz.nextInt();
		
		int result=a*b;
		System.out.println(result);
		

	}

}
