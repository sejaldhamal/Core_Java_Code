/*25. Find the Second Largest Number
Description: Write a program to find the second largest number from a set of two numbers.
Input: a = 10, b = 20
Output: 10
*/
package BasicArrayCode;

public class Q25SecondLargestNumber {

	public static void main(String[] args) {
		int a=10;
		int b=20;
	if(a<b)
	{
		System.out.println(a);
	}
	else {
		System.out.println(b);
	}


	}

}
